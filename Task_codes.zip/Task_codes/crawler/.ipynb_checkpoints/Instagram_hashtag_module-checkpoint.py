import time
from konlpy.tag import Okt
from selenium import webdriver
import pandas as pd
import numpy as np
from selenium.common.exceptions import NoSuchElementException
import sys
#from urllib.parse import quote

urlpartfront = 'https://www.instagram.com/explore/tags/'
hashtag_list = []
date_list = []
num_like = []

def hash_tag_crawl(url, outputfilename):

    driver = webdriver.Chrome('./chromedriver')
    driver.get(url)
    time.sleep(3)
    totalCount = driver.find_element_by_class_name('g47SY').text
    print("총 게시물:", totalCount)
    # posting 접근 -> Text 추출 -> next post

    tw = Okt()
    n=1
    post = driver.find_element_by_class_name("_9AhH0") #첫번째 게시물
    post.click()
    time.sleep(3)
    try:
        textpart = driver.find_element_by_class_name("C4VMK").text
        likepart = driver.find_element_by_css_selector("body > div._2dDPU.vCf6V > div.zZYga > div > article > div.eo2As > section.EDfFK.ygqzn > div > div > button > span").text
        datepart = driver.find_element_by_css_selector("body > div._2dDPU.vCf6V > div.zZYga > div > article > div.eo2As > div.k_Q0X.NnvRN > a > time").get_attribute("title")
        postword = textpart.split()
        templist = []
        for word in postword:
            temp = tw.pos(word)
            for pos in temp:
                if pos[1] == 'Hashtag':
                    templist.append(pos[0])
        hashtag_list.append(templist)
        num_like.append(likepart)
        date_list.append(datepart)
        driver.find_element_by_xpath("/html/body/div[4]/div[1]/div/div/a").click()  # next page

    except NoSuchElementException as e:
        num_like.append("video view")
        textpart = driver.find_element_by_class_name("C4VMK").text
        datepart = driver.find_element_by_css_selector(
            "body > div._2dDPU.vCf6V > div.zZYga > div > article > div.eo2As > div.k_Q0X.NnvRN > a > time").get_attribute(
            "title")
        postword = textpart.split()
        templist = []
        for word in postword:
            temp = tw.pos(word)
            for pos in temp:
                if pos[1] == 'Hashtag':
                    templist.append(pos[0])
        hashtag_list.append(templist)
        date_list.append(datepart)
        driver.find_element_by_xpath("/html/body/div[4]/div[1]/div/div/a").click()  # next page
    n=1
    while 1:
        n += 1
        try:
            time.sleep(np.random.randint(3,4))
            textpart = driver.find_element_by_class_name("C4VMK").text
            likepart = driver.find_element_by_css_selector(
                "body > div._2dDPU.vCf6V > div.zZYga > div > article > div.eo2As > section.EDfFK.ygqzn > div > div > button > span").text
            datepart = driver.find_element_by_css_selector(
                "body > div._2dDPU.vCf6V > div.zZYga > div > article > div.eo2As > div.k_Q0X.NnvRN > a > time").get_attribute(
                "title")
            postword = textpart.split()

            templist = []
            for word in postword:
                temp = tw.pos(word)
                for pos in temp:
                    if pos[1] == 'Hashtag':
                        templist.append(pos[0])
            hashtag_list.append(templist)
            num_like.append(likepart)
            date_list.append(datepart)
            time.sleep(np.random.randint(4, 6))
            driver.find_element_by_css_selector("body > div._2dDPU.vCf6V > div.EfHg9 > div > div > a.HBoOv.coreSpriteRightPaginationArrow").click() #next page
            n +=1
            print("{}th posting ...".format(n))
        except NoSuchElementException as e:
            time.sleep(np.random.randint(4, 6))
            driver.find_element_by_css_selector("body > div._2dDPU.vCf6V > div.EfHg9 > div > div > a.HBoOv.coreSpriteRightPaginationArrow").click()
            print('video contents pass')
            pass
        if n == totalCount:
            break

    df_dict = {}
    df_dict['hashtags'] = hashtag_list
    df_dict['numoflikes'] = num_like
    df_dict['date'] = date_list
    df = pd.DataFrame.from_dict(df_dict)
    df.to_csv(outputfilename+'.csv', index = False)
    print("Crawling end")

def main(argv):
    print("-python search keyword outputfile_name")
    search_keyword = sys.argv[1]
    outputfilename = sys.argv[2]
    url = urlpartfront+search_keyword
    hash_tag_crawl(url, outputfilename)

if __name__ == '__main__':
    main(sys.argv)


