import sys
from selenium import webdriver
import time
import pandas as pd
from urllib.parse import quote
import numpy as np

urlpartfront = 'https://twitter.com/search?f=tweets&vertical=default&q='
urlpartback = '&src=typd&lang=ko'

def twit_crawling(url, outputfilename):
    contents_list = []

    driver = webdriver.Chrome('./chromedriver')
    driver.get(url)

    time_now = time.time()
    print('Page access...')
    lastHeight = driver.execute_script("return document.body.scrollHeight")
    while True:
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        # define how many seconds to wait while dynamic page content loads
        time.sleep(np.random.randint(4, 6))
        newHeight = driver.execute_script("return document.body.scrollHeight")
        if newHeight == lastHeight:
            break
        else:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            lastHeight = newHeight

    print("{} seconds spent to scroll down".format(time.time() - time_now))

    txt_part = driver.find_elements_by_class_name('js-tweet-text-container')
    for txt in txt_part:
        text = txt.text
        contents_list.append(text)
    print("{} twitter mention crawling".format(len(contents_list)))

    dates = [element.get_attribute('title') for element in driver.find_elements_by_xpath(
        '//a[starts-with(@class, "tweet-timestamp js-permalink js-nav js-tooltip")]')]
    print("{} twitter mention crawling".format(len(dates)))
    print('\n')
    df_dict = {}
    df_dict['twit_text'] = contents_list
    df_dict['date'] = dates
    text_df = pd.DataFrame.from_dict(df_dict)
    text_df = text_df[text_df.date != ""]
    text_df['twit_text'] = text_df['twit_text'].str.replace("\n", "")
    text_df.to_csv(outputfilename, index=False)
    print('output file is saved...')
    #driver.close()

def main(argv):
    if len(argv) !=3:
        print("python 모듈이름, 검색어, outputfile명")
    searchkeyword = argv[1]
    outpuutfile_name = argv[2]
    url = urlpartfront + quote(searchkeyword) + urlpartback
    print(url)
    twit_crawling(url,outpuutfile_name)

if __name__ == '__main__':
    main(sys.argv)