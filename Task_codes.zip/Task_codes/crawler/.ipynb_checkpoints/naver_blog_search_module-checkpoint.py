import json
import math
import urllib.request
import urllib.error
import urllib.parse
from bs4 import BeautifulSoup
import sys
import pandas as pd

client_id = "GdiTfsJqLCPb_w5t6V83"
client_secret = "MhM83XC6gx"

title = []
link = []
description = []
postdate = []
df_dict = {}

def naver_blog_crawling(search_blog_keyword, display_count, sort_type):
    search_result_blog_page_count = get_blog_search_result_pagination_count(search_blog_keyword, display_count)
    get_blog_post(search_blog_keyword, display_count, search_result_blog_page_count, sort_type)

def get_blog_search_result_pagination_count(search_blog_keyword, display_count):
    encode_search_keyword = urllib.parse.quote(search_blog_keyword)
    url = "https://openapi.naver.com/v1/search/blog?query=" + encode_search_keyword
    request = urllib.request.Request(url)

    request.add_header("X-Naver-Client-Id", client_id)
    request.add_header("X-Naver-Client-Secret", client_secret)

    response = urllib.request.urlopen(request)
    response_code = response.getcode()

    if response_code is 200:
        response_body = response.read()
        response_body_dict = json.loads(response_body.decode('utf-8'))

        if response_body_dict['total'] == 0:
            blog_pagination_count = 0
        else:
            blog_pagination_total_count = math.ceil(response_body_dict['total'] / int(display_count))

            if blog_pagination_total_count >= 1000:
                blog_pagination_count = 1000
            else:
                blog_pagination_count = blog_pagination_total_count

            print("키워드 " + search_blog_keyword + "에 해당하는 포스팅 수 : " + str(response_body_dict['total']))
            print("키워드 " + search_blog_keyword + "에 해당하는 블로그 실제 페이징 수 : " + str(blog_pagination_total_count))
            print("키워드 " + search_blog_keyword + "에 해당하는 블로그 처리할 수 있는 페이징 수 : " + str(blog_pagination_count))

        return blog_pagination_count


def get_blog_post(search_blog_keyword, display_count, search_result_blog_page_count, sort_type):
    encode_search_blog_keyword = urllib.parse.quote(search_blog_keyword)

    for i in range(1, search_result_blog_page_count + 1):
        url = "https://openapi.naver.com/v1/search/blog?query=" + encode_search_blog_keyword + "&display=" + str(
            display_count) + "&start=" + str(i) + "&sort=" + sort_type

        request = urllib.request.Request(url)

        request.add_header("X-Naver-Client-Id", client_id)
        request.add_header("X-Naver-Client-Secret", client_secret)

        response = urllib.request.urlopen(request)
        response_code = response.getcode()

        if response_code is 200:
            response_body = response.read()
            response_body_dict = json.loads(response_body.decode('utf-8'))

            for j in range(0,len(response_body_dict['items'])):
                title.append(response_body_dict['items'][j]['title'])
                link.append(response_body_dict['items'][j]['link'])
                description.append(response_body_dict['items'][j]['description'])
                postdate.append(response_body_dict['items'][j]['postdate'])
        if i % 10 == 0: print("{}th search page...".format(i))
    df_dict['title'] = title
    df_dict['link'] = link
    df_dict['description'] = description
    df_dict['postdate'] = postdate
    df = pd.DataFrame.from_dict(df_dict)
    df.to_csv(search_blog_keyword+'_blogsearch.csv', index = False)


def main(argv):
    searchkeyword = argv[1]
    pagecount = argv[2]
    searchopt = argv[3]
    naver_blog_crawling(searchkeyword, pagecount, searchopt)

if __name__ == '__main__':
    main(sys.argv)



