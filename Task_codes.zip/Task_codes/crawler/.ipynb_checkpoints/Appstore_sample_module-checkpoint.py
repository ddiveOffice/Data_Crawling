from bs4 import BeautifulSoup
import urllib.request
import sys
import pandas as pd
import numpy as np
import time


def crawling_review(gameid, outputfilename):
    urlpartfront = "https://itunes.apple.com/kr/rss/customerreviews/page="
    urlpartback = "/id=" + str(gameid) + "/sortby=mostrecent/xml?urlDesc=/customerreviews/id=" + str(gameid) + "/all/xml"
    review_date_list = []
    review_text_title = []
    review_text_list = []
    review_rating_list = []
    for n in range(1, 11):  # review page
        url = urlpartfront + str(n) + urlpartback
        q = urllib.request.Request(url)
        q.add_header('User-Agent', 'Mozilla/5.0')
        responses = urllib.request.urlopen(q)
        time.sleep(np.random.randint(5, 15))
        soup = BeautifulSoup(responses, 'lxml', from_encoding='utf-8')
        contentspart = soup.find_all('content', type="text")
        for txt in contentspart:
            review_text_list.append(txt.find_all(text=True))

        contentdate = soup.find_all('entry')
        for date in contentdate:
            date_text = date.find('updated')
            review_date_list.append(date_text.find_all(text=True))

        titlepart = soup.find_all('entry')
        for title in titlepart:
            title_text = title.find('title')
            review_text_title.append(title_text.find_all(text=True))

        ratingpart = soup.find_all('im:rating')
        for star in ratingpart:
            review_rating_list.append(star.find_all(text=True))

        if n % 10 == 0:
            print("{}th review crawling...".format(n))
        time.sleep(np.random.randint(1, 15))

    print(len(review_date_list), len(review_text_title), len(review_text_list), len(review_rating_list))

    review_date_list2 = np.array(review_date_list).reshape((-1))
    review_text_title2 = np.array(review_text_title).reshape((-1))
    review_text_list2 = np.array(review_text_list).reshape((-1))
    review_rating_list2 = np.array(review_rating_list).reshape((-1))

    review_df2 = pd.DataFrame(
        {'date': review_date_list2, 'review_title': review_text_title2, 'review_text': review_text_list2,
         'rating': review_rating_list2})
    review_df2.to_csv(outputfilename,index=False)
    print("crawling success..")
def main(argv):
    gameid_list = argv[1]
    outputfilename_list = argv[2]
    crawling_review(gameid, outputfilename)

if __name__ == '__main__':
    main(sys.argv)